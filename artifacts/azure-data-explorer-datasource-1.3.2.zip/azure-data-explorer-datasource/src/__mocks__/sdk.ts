import {QueryCtrl} from './query_ctrl';

export {
  QueryCtrl,
};
