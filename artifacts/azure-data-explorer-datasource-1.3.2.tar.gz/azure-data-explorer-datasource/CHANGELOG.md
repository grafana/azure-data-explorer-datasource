# Change Log

## [1.3.2] - 2019-06-19

- Bugfix for issue #8
- Updated packages
- Added circleci
