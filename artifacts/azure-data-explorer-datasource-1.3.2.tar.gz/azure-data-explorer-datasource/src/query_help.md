#### Writing Queries for Template Variables

See the [docs](https://github.com/grafana/azure-monitor-datasource#templating-with-variables) for details and examples.
